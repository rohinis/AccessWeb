import time

with open('e.txt', 'a') as f:
    for i in range(5):
        f.write("line number "+str(i))
        time.sleep(1)
        f.write('\n')
