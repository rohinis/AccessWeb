#!/bin/sh
touch in.txt
for((n=1;n<=225;n++))
  do
  touch $n.txt
  echo "File number $n" >> $n.txt
done
mkdir LessItems
mkdir EmptyFolder

cd LessItems

touch 1.txt
touch 2.txt



