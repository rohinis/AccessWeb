import time, os, sys, re
 
seconds=os.environ['PAS_SLEEPTIME']
print("job is sleeping for "+seconds+" seconds")
time.sleep(int(seconds))
