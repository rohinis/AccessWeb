#
# (c) Copyright 2017 Altair Engineering, Inc.  All rights reserved.
#
# This code is provided as is without any warranty, express or implied,
# or indemnification of any kind.
# All other terms and conditions are as specified in the Altair PBS EULA.
#

import base64

import masterFileAnalyzer

if refreshSourceName == "PRIMARY_FILE":
    deleteArg("INCLUDE_FILES")
    deleteArg("INCLUDE_FILE_MAPPING")

    # Get the chosen master file value
    inputVal = getValue(refreshSourceName)
    
    if inputVal:
        # Identify the include file arguments from the chosen master file
        (includeVal, includeFileMap) = masterFileAnalyzer.parseMasterFileForIncludePaths(inputVal, "INCLUDE ", False)
        if includeVal:
            # If not empty insert into the application
            newIncludeArg = {"name": "INCLUDE_FILES", "argType": "filemulti", "displayName": "Include Files",
                             "displayable": True, "value": includeVal,
                             "description": "Add extra file to be sent to a remote server", "requiredValue": True,
                             "refreshOnUpdate": False}
            insertArg(newIncludeArg)

            if includeFileMap:
                includeFileMap = base64.b64encode(includeFileMap.encode()).decode()
                newIncFlMapArg = {"name": "INCLUDE_FILE_MAPPING", "argType": "string", "value": includeFileMap,
                                  "description": "Include Files Map Base64 encoded",
                                  "displayName": "INCLUDE FILE MAPPING", "requiredValue": False,
                                  "refreshOnUpdate": False}
                insertArg(newIncFlMapArg)
