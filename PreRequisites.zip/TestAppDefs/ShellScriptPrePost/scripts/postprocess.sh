cp /home/BUILDS/NewStack-PreRequisites/MultipleFilesJS.zip .
/usr/bin/unzip MultipleFilesJS.zip

cp /home/BUILDS/NewStack-PreRequisites/MultipleFilesIconsJS.zip .
/usr/bin/unzip MultipleFilesIconsJS.zip

cp /home/BUILDS/NewStack-PreRequisites/MultipleFolderJS.zip .
/usr/bin/unzip MultipleFolderJS.zip

cp /home/BUILDS/NewStack-PreRequisites/MultipleFolderIconsJS.zip .
/usr/bin/unzip MultipleFolderIconsJS.zip

cp /home/BUILDS/NewStack-PreRequisites/MultipleFolderFilesJS.zip .
/usr/bin/unzip MultipleFolderFilesJS.zip

cp /home/BUILDS/NewStack-PreRequisites/MultipleFolderFilesIconsJS.zip .
/usr/bin/unzip MultipleFolderFilesIconsJS.zip


