cwd=$(pwd)

source /etc/access.conf
source /etc/pbs.conf

sed -i 's,CURRENT_PATH,'"$cwd"',g' filesAction.py
sed -i 's,CURRENT_PATH,'"$cwd"',g' genericactions.json
sed -i 's,CURRENT_PATH,'"$cwd"',g' $cwd/TestAppDefs/ShellScriptPrePost/scripts/postprocess.sh
sed -i 's,CURRENT_PATH,'"$cwd"',g' createTestData.sh

# Remove all directories in sample-applications
ls -d $SERVER_INSTALLATION_DIR/home/data/pas/sample-applications/*/| xargs rm -rf

cp -rf $cwd/TestAppDefs/* $SERVER_INSTALLATION_DIR/home/data/pas/sample-applications/
rm -f $SERVER_INSTALLATION_DIR/home/data/pas/sample-applications/resourcede

rm -rf $SERVER_INSTALLATION_DIR/home/data/pas/targets/localhost/repository/applications/*

cp -f $cwd/TestAppDefs/resourcedef $PBS_HOME/server_priv/

rm -f $SERVER_INSTALLATION_DIR/home/data/time_stamp.txt

cd  $SERVER_INSTALLATION_DIR/home/config/pa/
mv genericactions.json genericactions-ori-json

cp $cwd/genericactions.json  $SERVER_INSTALLATION_DIR/home/config/pa/genericactions.json

qmgr -c "create resource pas_applications_enabled"
qmgr -c "set resource pas_applications_enabled type = string_array"
qmgr -c "set resource pas_applications_enabled flag = h"

qmgr -c "create queue compute"
qmgr -c "set queue compute queue_type = Execution"
qmgr -c "set queue compute enabled = True"
qmgr -c "set queue compute started = False"

qmgr -c "create queue accessQueue"
qmgr -c "set queue accessQueue queue_type = Execution"
qmgr -c "set queue accessQueue enabled = True"
qmgr -c "set queue accessQueue started = True"
